export const supportNetwork = { 
    56 : {
        name : "Binanace",
        chainId : 56,
        rpc : "https://bsc.publicnode.com",
        symbol : 'BNB'
    },
    // 97 : {
    //     name : "Binanace",
    //     chainId : 97,
    //     rpc : "https://data-seed-prebsc-1-s3.binance.org:8545/",
    //     symbol : 'BNB'
    // }
}