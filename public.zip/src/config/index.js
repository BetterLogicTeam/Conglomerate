export const BRIDGE_URL = "https://bridge.walletconnect.org";
// export const RPC_URL = "https://eth-goerli.public.blastapi.io"; goerli test network
export const RPC_URL = "https://bsc.publicnode.com";
export const CHAIN_ID = 56 ;
